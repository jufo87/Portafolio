# README - Entregable Final (Generado)

## Requisitos
- Java 11+ (o la versión indicada en pom/build)
- Maven 3.6+ o Gradle
- MySQL o base de datos según `application.properties`
- Node/npm si hay frontend

## Pasos para ejecutar
1. Configurar variables de entorno / application.properties (URL BD, usuario, contraseña).
2. Ejecutar `mvn clean package` o `./gradlew build`.
3. Ejecutar: `java -jar target/tu-app.jar` o desplegar en Tomcat.

## Tests
- Ejecutar `mvn test`.

## Contacto
- Proyecto revisado automáticamente por asistente. Revisar y ajustar configuraciones locales.
