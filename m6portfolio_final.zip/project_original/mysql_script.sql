CREATE DATABASE IF NOT EXISTS training_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE training_db;

CREATE TABLE instructores (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(255),
  email VARCHAR(255)
);

CREATE TABLE cursos (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(255),
  descripcion TEXT,
  fecha_inicio DATETIME,
  fecha_fin DATETIME,
  cupos INT,
  instructor_id BIGINT,
  FOREIGN KEY (instructor_id) REFERENCES instructores(id)
);

CREATE TABLE empleados (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(255),
  email VARCHAR(255),
  usuario VARCHAR(100),
  password VARCHAR(255),
  rol VARCHAR(50)
);

CREATE TABLE inscripciones (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  curso_id BIGINT,
  empleado_id BIGINT,
  fecha_inscripcion DATETIME,
  FOREIGN KEY (curso_id) REFERENCES cursos(id),
  FOREIGN KEY (empleado_id) REFERENCES empleados(id)
);

INSERT INTO instructores (nombre, email) VALUES ('Lucía Gómez', 'lucia.gomez@example.com');
INSERT INTO cursos (titulo, descripcion, fecha_inicio, fecha_fin, cupos, instructor_id) VALUES ('Introducción a Spring', 'Curso básico', '2025-01-10 09:00:00', '2025-01-15 17:00:00', 20, 1);
INSERT INTO empleados (nombre, email, usuario, password, rol) VALUES ('Juan Perez','juan.perez@example.com','empleado','empleado','EMPLEADO'), ('Admin Demo','admin@example.com','admin','admin','ADMIN');
