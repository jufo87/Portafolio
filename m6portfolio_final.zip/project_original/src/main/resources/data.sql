INSERT INTO instructores (id, nombre, email) VALUES (1, 'Lucía Gómez', 'lucia.gomez@example.com');
INSERT INTO cursos (id, titulo, descripcion, fecha_inicio, fecha_fin, cupos, instructor_id) VALUES (1, 'Introducción a Spring', 'Curso básico de Spring Boot', '2025-01-10T09:00:00', '2025-01-15T17:00:00', 20, 1);
INSERT INTO empleados (id, nombre, email, usuario, password, rol) VALUES (1, 'Juan Perez', 'juan.perez@example.com', 'empleado', 'empleado', 'EMPLEADO');
INSERT INTO empleados (id, nombre, email, usuario, password, rol) VALUES (2, 'Admin Demo', 'admin@example.com', 'admin', 'admin', 'ADMIN');
