package com.example.training.controller;

import com.example.training.repository.CursoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {

    private final CursoRepository cursoRepository;

    public WebController(CursoRepository cursoRepository) {
        this.cursoRepository = cursoRepository;
    }

    @GetMapping("/admin/cursos")
    public String adminCursos(Model model) {
        model.addAttribute("cursos", cursoRepository.findAll());
        return "admin/cursos";
    }

    @GetMapping("/empleado/cursos")
    public String empleadoCursos(Model model) {
        model.addAttribute("cursos", cursoRepository.findAll());
        return "empleado/cursos";
    }

    @GetMapping("/login")
    public String login() { return "login"; }
}
