package com.example.training.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "instructores")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Instructor {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String email;

    @OneToMany(mappedBy = "instructor")
    private Set<Curso> cursos = new HashSet<>();
}
