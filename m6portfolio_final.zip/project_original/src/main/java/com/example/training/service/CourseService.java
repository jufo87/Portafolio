package com.example.training.service;

import com.example.training.model.Curso;
import com.example.training.model.Empleado;
import com.example.training.model.Inscripcion;
import com.example.training.repository.CursoRepository;
import com.example.training.repository.InscripcionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CourseService {
    private final CursoRepository cursoRepo;
    private final InscripcionRepository insRepo;

    public CourseService(CursoRepository cursoRepo, InscripcionRepository insRepo) {
        this.cursoRepo = cursoRepo;
        this.insRepo = insRepo;
    }

    public List<Curso> listAll() { return cursoRepo.findAll(); }
    public Curso find(Long id) { return cursoRepo.findById(id).orElseThrow(); }
    public Curso save(Curso c) { return cursoRepo.save(c); }

    public Inscripcion register(Curso curso, Empleado empleado) {
        Inscripcion i = Inscripcion.builder()
                .curso(curso)
                .empleado(empleado)
                .fechaInscripcion(LocalDateTime.now())
                .build();
        return insRepo.save(i);
    }
}
