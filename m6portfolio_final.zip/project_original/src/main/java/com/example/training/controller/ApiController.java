package com.example.training.controller;

import com.example.training.model.Curso;
import com.example.training.model.Empleado;
import com.example.training.model.Inscripcion;
import com.example.training.repository.CursoRepository;
import com.example.training.repository.EmpleadoRepository;
import com.example.training.service.CourseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ApiController {

    private final CursoRepository cursoRepo;
    private final EmpleadoRepository empleadoRepo;
    private final CourseService courseService;

    public ApiController(CursoRepository cursoRepo, EmpleadoRepository empleadoRepo, CourseService courseService) {
        this.cursoRepo = cursoRepo;
        this.empleadoRepo = empleadoRepo;
        this.courseService = courseService;
    }

    @GetMapping("/cursos")
    public ResponseEntity<List<Curso>> cursos() {
        return ResponseEntity.ok(cursoRepo.findAll());
    }

    @PostMapping("/inscripciones")
    public ResponseEntity<Inscripcion> inscribir(@RequestParam Long cursoId, @RequestParam Long empleadoId) {
        Curso curso = cursoRepo.findById(cursoId).orElseThrow();
        Empleado emp = empleadoRepo.findById(empleadoId).orElseThrow();
        Inscripcion ins = courseService.register(curso, emp);
        return ResponseEntity.created(URI.create("/api/inscripciones/" + ins.getId())).body(ins);
    }
}
