# Training Management - Proyecto Spring Boot

## Descripción del servicio y casos de uso
Aplicación interna para gestionar capacitaciones de personal. Permite:
- Registrar cursos (título, descripción, fechas, cupos).
- Gestionar instructores y empleados.
- Inscribir empleados a cursos.
- Panel de administración (/admin/cursos) para usuarios con rol ADMIN.
- Panel de empleado (/empleado/cursos) para usuarios con rol EMPLEADO.
- Exponer APIs REST para interoperabilidad: consultar cursos y registrar inscripciones.

Casos de uso principales:
1. Un administrador crea/edita/elimina cursos y asigna instructores.
2. Un empleado consulta cursos disponibles y se inscribe.
3. Un sistema externo consulta `/api/cursos` para sincronizar catálogos de formación.
4. Un servicio de RRHH registra inscripciones vía `/api/inscripciones`.

## Arquitectura y capas
- Controller (web y REST)
- Service (lógica de negocio)
- Repository (JPA)
- Model (entidades JPA)

## Diagrama de clases (PlantUML)
```plantuml
@startuml
class Curso {
  +Long id
  +String titulo
  +String descripcion
  +LocalDateTime fechaInicio
  +LocalDateTime fechaFin
  +Integer cupos
}
class Instructor { +Long id; +String nombre; +String email }
class Empleado { +Long id; +String nombre; +String email; +String usuario; +String rol }
class Inscripcion { +Long id; +LocalDateTime fechaInscripcion }

Curso --> Instructor
Curso "1" --> "*" Inscripcion
Empleado "1" --> "*" Inscripcion
@enduml
```

## Flujo de navegación (texto)
1. Usuario abre `/login` y se autentica.
2. Si es ADMIN: accede a `/admin/cursos` (panel de gestión).
3. Si es EMPLEADO: accede a `/empleado/cursos` para ver e inscribirse.
4. Clientes externos usan `/api/cursos` para obtener listado y `/api/inscripciones` para registrar.

## Cómo compilar y ejecutar (instrucciones)
Requisitos:
- Java 17
- Maven 3.6+

Compilar y ejecutar:
```bash
mvn clean package
java -jar target/training-management-0.0.1-SNAPSHOT.jar
```
La aplicación arranca en `http://localhost:8080`.
- H2 Console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:trainingdb`, user `sa`, sin password).
- Swagger UI: `/swagger-ui/index.html` (si está disponible).

Credenciales demo (in-memory, definidas en SecurityConfig):
- admin / admin  (ROLE_ADMIN)
- empleado / empleado (ROLE_EMPLEADO)

## Cómo probar (curl)
Listar cursos (necesita autenticación básica):
```
curl -u empleado:empleado http://localhost:8080/api/cursos
```
Inscribir empleado (ejemplo):
```
curl -X POST -u admin:admin "http://localhost:8080/api/inscripciones?cursoId=1&empleadoId=1"
```

## Gestión del proyecto - tablero (mock)
Se incluye un archivo `project-board.md` que muestra tareas y columnas sugeridas (Backlog, To Do, In Progress, Done). Para evidencia, capture pantallas del tablero real y añádalas al directorio `evidence/`.

## Pruebas e integraciones
- Usar Postman o curl para probar endpoints.
- Para integración con otros sistemas, permita CORS o utilice un token/Basic Auth para llamadas programáticas.

## Notas de seguridad y mejoras
- En producción, sustituir autenticación en memoria por JWT o base de datos con contraseñas hasheadas (BCrypt).
- Validar entradas con `@Valid` y DTOs.
- Añadir pruebas unitarias y de integración (JUnit + MockMvc).

## Entregables incluidos
- Código fuente del proyecto (skeleton) listo para compilar.
- `data.sql` con datos de ejemplo.
- `mysql_script.sql` para crear tablas y datos en MySQL.
- `README.md` con instrucciones y casos de uso.
- `project-board.md` (mock del tablero de gestión).
- `diagrams/` incluye el PlantUML del diagrama de clases.
