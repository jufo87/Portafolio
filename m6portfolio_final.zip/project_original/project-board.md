# Tablero de gestión (mock)

Columnas: Backlog | To Do | In Progress | Done

## Backlog
- Definir alcance detallado del módulo de inscripciones
- Diseñar esquema de la base de datos final

## To Do
- Inicializar proyecto Spring Boot
- Crear entidades Curso, Empleado, Instructor, Inscripcion
- Configurar seguridad básica (roles)

## In Progress
- Implementar APIs REST básicos (/api/cursos, /api/inscripciones)

## Done
- Crear README y scripts iniciales
- Crear templates Thymeleaf mínimos

---
Asigne tarjetas a responsables y fechas de entrega en su gestor preferido (Trello/Jira/GitHub Projects).
