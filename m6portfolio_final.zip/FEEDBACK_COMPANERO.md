# Feedback simulado (como compañero)

1. **Documentación insuficiente** — Añadir README con pasos de instalación, ejemplos y variables necesarias.  
2. **Faltan pruebas automatizadas** — Agregar pruebas unitarias para servicios clave.  
3. **Mejoras de UX** — Mensajes de error claros y validaciones en formularios.

Cambios propuestos: README detallado, 3 tests JUnit, validaciones `@Valid` en DTOs.
